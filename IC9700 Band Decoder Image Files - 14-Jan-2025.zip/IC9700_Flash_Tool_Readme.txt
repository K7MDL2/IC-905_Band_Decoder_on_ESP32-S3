IC-9700 Band Decoder Flash Download Tool image files

This file set is for the IC-9700 and configured to run on a ESP32-S3-DevKitC-1 N16R8 clone board.  

I cannot test it as I do not have this radio and I am awaiting to hear from any 9700 owners how it works for them.   It is different form the IC-905 version only in that is has the CI-V address and USB vendor IDs altered to match the IC-9700.


To flash firmware to your ESP32-S3 board, follow the instructions located on the project GitHub site Wiki pages.

https://github.com/K7MDL2/IC-905_Band_Decoder_on_ESP32-S3/wiki/Using-Flash-Download-Tool


There are 3 files plus this readme file.  The filenames are listed below along with the offset number that you will enter with it in the Flash Download Tool UI.

1. Bootloader.bin   0x0
2. IC905_ESP32-S3_PTT_Breakout.bin  0x10000  (1 plus 4 zeros)
3. partition-table.bin 0x8000 (8plus 3 zeros)
